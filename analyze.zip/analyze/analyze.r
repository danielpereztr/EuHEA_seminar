library(readxl)
library(dplyr)
library(tidyr)
library(reshape2)
library(survival)
library(broom)
library(ggplot2)

# Import the data
survey1 <- read_excel("survey1.xlsx", col_names = T)
survey2 <- read_excel("survey2.xlsx", col_names = T)
design <- read_excel("design.xlsx", col_names = T)

# Rename the variables
names(survey1) <- c("timestamp", "age", "gender", "education", "country",
                    "cs14", "cs9", "cs8", "cs13", "cs6", "cs15", "cs7", 
                    "cs4")

# Add a respondent identificator
survey1$pid <- 1:nrow(survey1)

names(survey2) <- c("timestamp", "age", "gender", "education", "country",
                    "cs1", "cs16", "cs11", "cs2", "cs3", "cs12", "cs10",
                    "cs5")

survey2$pid <- (nrow(survey1)+1):((nrow(survey1))+nrow(survey2))

# Long format and binary choice variable (survey1)
survey1 <- survey1 %>%
  pivot_longer(
    cols = starts_with("cs"),
    names_to = "choice_set",
    values_to = "choice"
  )

survey1 <- survey1 %>%
  slice(rep(1:n(), each = 2))

survey1$alt <- rep(c(1,2), times = nrow(survey1)/2)

survey1$choice1 <- ifelse(survey1$alt == 1 & survey1$choice == "Alternative A", 1, 0)
survey1$choice1 <- ifelse(survey1$alt == 2 & survey1$choice == "Alternative B", 1, survey1$choice1)
survey1$choice <- survey1$choice1
survey1$choice1 <- NULL


# Long format and binary choice variable (survey2)
survey2 <- survey2 %>%
  pivot_longer(
    cols = starts_with("cs"),
    names_to = "choice_set",
    values_to = "choice"
  )

survey2 <- survey2 %>%
  slice(rep(1:n(), each = 2))

survey2$alt <- rep(c(1,2), times = nrow(survey2)/2)

survey2$choice1 <- ifelse(survey2$alt == 1 & survey2$choice == "Alternative A", 1, 0)
survey2$choice1 <- ifelse(survey2$alt == 2 & survey2$choice == "Alternative B", 1, survey2$choice1)
survey2$choice <- survey2$choice1
survey2$choice1 <- NULL

# Join the surveys
survey <- rbind(survey1, survey2)

# Modify the choice_set variable in design to merge the dataframes
design$choice_set <- paste0("cs", design$choice_set)

# Agrupation variable
survey$gid <- rep(1:(nrow(survey)/2), each = 2)

# Merge the responses with the design matrix
dce <- merge(survey, design, by = c("alt", "choice_set"))

# Code the wage variable as a continuous variable
dce$salary <- ifelse(dce$wage_35000 == 1, 35000, 
                     ifelse(dce$wage_37500 == 1, 37500, 
                            ifelse(dce$wage_40000 == 1, 40000, 
                                   ifelse(dce$wage_42500 == 1, 42500, 
                                          ifelse(dce$wage_45000, 45000, 32500)))))
# Order the results
dce <- dce[order(dce$pid, dce$gid, decreasing = FALSE),]

# Analyze the results
mod <- clogit(choice ~ two_days + four_days + all_days + core_hours + 
                fully_flexible + no_differences + salary + strata(gid), 
              data = dce)

summary(mod)

# Generate database to plot bar graph

tidy_mod <- broom::tidy(mod) %>%
  # Opcional: quitar el intercepto si aparece
  filter(term != "(Intercept)") %>%
  # Calcular OR y límite inferior y superior del IC 95%
  mutate(
    OR    = estimate,
    lower = estimate - 1.96 * std.error,
    upper = estimate + 1.96 * std.error,
    # Para etiquetas más legibles
    term = recode(term,
                  two_days = "2 days/week",
                  four_days = "4 days/week",
                  all_days = "All days/week",
                  core_hours = "Core schedule",
                  fully_flexible = "Fully flexible",
                  no_differences = "No differences",
                  salary = "Salary")
  )

tidy_mod2 <- tidy_mod %>% 
  # recode your term → friendly English
  mutate(
    label = recode(term,
                   two_days       = "2 days/week",
                   four_days      = "4 days/week",
                   all_days       = "All days/week",
                   core_hours     = "Core schedule",
                   fully_flexible = "Fully flexible",
                   no_differences = "No differences",
                   salary         = "Salary"
    ),
    # assign each label to one of your three groups
    attribute = case_when(
      label %in% c("2 days/week","4 days/week","All days/week") ~ "Remote work days",
      label %in% c("Core schedule","Fully flexible") ~ "Schedule flexibility",
      label %in% c("No differences") ~ "Promotion opportunities",
      TRUE ~ "Other"
    ),
    # force the drawing order (so that the bars stack in the order you like)
    label = factor(label, levels = c(
      "2 days/week","4 days/week","All days/week",
      "Core schedule","Fully flexible",
      "No differences",
      "Salary"
    ))
  )

# Plot bar graph
ggplot(tidy_mod2[1:6,], aes(x = estimate, y = label)) +
  geom_col(fill = "steelblue", width = 0.6) +
  geom_errorbarh(aes(xmin = lower, xmax = upper), height = 0.2) +
  geom_vline(xintercept = 0, linetype = "dashed") +
  labs(
    x = "Utility (β)",
    y = NULL,
    title = "DCE Utilities from the Conditional Logit Model",
    subtitle = "Grouped by attribute with 95% confidence intervals"
  ) +
  facet_grid(attribute ~ ., 
             scales = "free_y",     # each facet gets its own y-axis categories
             space  = "free",       # allow space to adjust per group
             switch = "y"           # move strip labels to the left
  ) +
  theme_minimal(base_size = 14) +
  theme(
    strip.placement       = "outside",
    strip.text.y.left     = element_text(angle = 0, face = "bold", hjust = 0),
    panel.spacing         = unit(0.5, "lines"),
    plot.title            = element_text(face = "bold"),
    axis.text.y           = element_text(size = 12)
  ) +
  coord_cartesian(
    xlim = c(min(tidy_mod2$lower) * 0.9, max(tidy_mod2$upper) * 1.1)
  )
